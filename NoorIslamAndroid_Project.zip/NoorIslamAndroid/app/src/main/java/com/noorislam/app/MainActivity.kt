package com.noorislam.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Forest = Color(0xFF123B32)
private val ForestDeep = Color(0xFF092B25)
private val Sage = Color(0xFF526D65)
private val Gold = Color(0xFFD9C58F)
private val Sky = Color(0xFF397C9B)
private val Cream = Color(0xFFF5F0E4)
private val Ink = Color(0xFF24352F)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NoorIslamApp() }
    }
}

private enum class Page(val title: String) {
    HOME("الرئيسية"), QURAN("القرآن"), PRAYER("الصلاة"),
    ADHKAR("الأذكار"), TASBEEH("التسبيح"), DUA("الدعاء"),
    HADITH("الأحاديث"), CALENDAR("التقويم"), MORE("المزيد")
}

@Composable
fun NoorIslamApp() {
    var page by remember { mutableStateOf(Page.HOME) }
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Forest, secondary = Gold, background = ForestDeep,
            surface = Cream, onPrimary = Color.White, onSurface = Ink
        )
    ) {
        Scaffold(
            containerColor = ForestDeep,
            bottomBar = {
                NavigationBar(containerColor = Cream, contentColor = Forest) {
                    val tabs = listOf(Page.HOME, Page.QURAN, Page.PRAYER, Page.ADHKAR, Page.MORE)
                    tabs.forEach { item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = {
                                Icon(
                                    imageVector = item.icon(),
                                    contentDescription = item.title
                                )
                            },
                            label = { Text(item.title, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Forest,
                                selectedTextColor = Forest,
                                indicatorColor = Gold.copy(alpha = .35f),
                                unselectedIconColor = Sage
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding)
                    .background(ForestDeep)
            ) {
                Header(page.title)
                when (page) {
                    Page.HOME -> HomeScreen(onOpen = { page = it })
                    Page.QURAN -> QuranScreen()
                    Page.PRAYER -> PrayerScreen()
                    Page.ADHKAR -> AdhkarScreen()
                    Page.TASBEEH -> TasbeehScreen()
                    Page.DUA -> SimpleContentScreen("الأدعية", "ستُضاف مجموعة أدعية موثوقة ومصنفة في مرحلة المحتوى.")
                    Page.HADITH -> SimpleContentScreen("الأحاديث النبوية", "ستُضاف الأحاديث مع التخريج والمصدر ودرجة الحديث بعد مراجعتها.")
                    Page.CALENDAR -> SimpleContentScreen("التقويم الهجري", "سيُربط التقويم بمصدر تاريخ موثوق مع توضيح اختلاف الرؤية المحلية.")
                    Page.MORE -> MoreScreen(onOpen = { page = it })
                }
            }
        }
    }
}

private fun Page.icon(): ImageVector = when (this) {
    Page.HOME -> Icons.Filled.Home
    Page.QURAN -> Icons.Filled.MenuBook
    Page.PRAYER -> Icons.Filled.Explore
    Page.ADHKAR -> Icons.Filled.DarkMode
    Page.TASBEEH -> Icons.Filled.RadioButtonChecked
    Page.DUA -> Icons.Filled.PanTool
    Page.HADITH -> Icons.Filled.AutoStories
    Page.CALENDAR -> Icons.Filled.CalendarMonth
    Page.MORE -> Icons.Filled.GridView
}

@Composable
private fun Header(title: String) {
    Row(
        Modifier.fillMaxWidth().background(Forest).padding(horizontal = 20.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text("نور الإسلام", color = Gold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(title, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ScreenColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().background(ForestDeep).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        content = content
    )
}

@Composable
private fun SectionCard(
    title: String,
    subtitle: String? = null,
    icon: ImageVector? = null,
    tint: Color = Forest,
    onClick: (() -> Unit)? = null,
    content: (@Composable ColumnScope.() -> Unit)? = null
) {
    Card(
        modifier = Modifier.fillMaxWidth().then(
            if (onClick != null) Modifier.clickable { onClick() } else Modifier
        ),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Cream),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (icon != null) Icon(icon, null, tint = tint, modifier = Modifier.size(27.dp))
                Spacer(Modifier.width(10.dp))
                Text(title, color = ForestDeep, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
            if (subtitle != null) Text(subtitle, color = Sage, fontSize = 13.sp)
            content?.invoke(this)
        }
    }
}

@Composable
private fun HomeScreen(onOpen: (Page) -> Unit) {
    ScreenColumn {
        SectionCard(
            title = "مواقيت الصلاة",
            subtitle = "سيتم عرض المواقيت الدقيقة بعد إعداد الموقع وطريقة الحساب.",
            icon = Icons.Filled.Explore,
            tint = Sky,
            onClick = { onOpen(Page.PRAYER) }
        ) {
            Text("الفجر   •   الظهر   •   العصر   •   المغرب   •   العشاء",
                color = Ink, fontSize = 12.sp)
        }
        Text("الأقسام الرئيسية", color = Gold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        val items = listOf(
            Triple("القرآن الكريم", Icons.Filled.MenuBook, Page.QURAN),
            Triple("الصلاة والقبلة", Icons.Filled.Explore, Page.PRAYER),
            Triple("الأذكار", Icons.Filled.DarkMode, Page.ADHKAR),
            Triple("التسبيح", Icons.Filled.RadioButtonChecked, Page.TASBEEH),
            Triple("الأدعية", Icons.Filled.PanTool, Page.DUA),
            Triple("الأحاديث", Icons.Filled.AutoStories, Page.HADITH),
            Triple("التقويم الهجري", Icons.Filled.CalendarMonth, Page.CALENDAR),
            Triple("المزيد", Icons.Filled.GridView, Page.MORE)
        )
        items.chunked(2).forEach { rowItems ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                rowItems.forEach { (label, icon, destination) ->
                    Card(
                        modifier = Modifier.weight(1f).height(112.dp).clickable { onOpen(destination) },
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Forest)
                    ) {
                        Column(
                            Modifier.fillMaxSize().padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(icon, null, tint = Gold, modifier = Modifier.size(30.dp))
                            Spacer(Modifier.height(8.dp))
                            Text(label, color = Color.White, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                if (rowItems.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        SectionCard(
            title = "محتوى إسلامي",
            subtitle = "مساحة للقصص والدروس وشرح القرآن ومقاطع تعليمية موثوقة."
        )
        Text(
            "مع تحيات صانع التطبيق عمر الوكيل ❤️\nصنع بكل حب لخدمة المسلمين",
            color = Gold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(),
            fontSize = 13.sp
        )
    }
}

@Composable
private fun QuranScreen() {
    val surahs = listOf(
        "الفاتحة" to "7 آيات",
        "البقرة" to "286 آية",
        "آل عمران" to "200 آية",
        "النساء" to "176 آية",
        "المائدة" to "120 آية",
        "الأنعام" to "165 آية"
    )
    ScreenColumn {
        SectionCard("آخر قراءة", "لم يتم تسجيل موضع قراءة بعد.", Icons.Filled.Bookmark, tint = Gold)
        Text("السور", color = Gold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text("هذه قائمة تجريبية للواجهة. سيُضاف نص المصحف المدني الموثق كاملًا في حزمة محتوى مستقلة.",
            color = Color.White, fontSize = 12.sp)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(surahs) { (name, count) ->
                SectionCard(name, count, Icons.Filled.MenuBook, tint = Gold) {
                    Text("فتح السورة سيُفعّل بعد إضافة نص المصحف المعتمد.", color = Sage, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun PrayerScreen() {
    ScreenColumn {
        SectionCard("مواقيت الصلاة", "لا نعرض أوقاتًا تقديرية حتى لا نعطيك مواقيت غير دقيقة.", Icons.Filled.AccessTime, tint = Sky)
        SectionCard("القبلة", "سيتم تفعيل اتجاه القبلة باستخدام مستشعرات الهاتف بعد اختبارها على الجهاز.", Icons.Filled.Explore, tint = Sky)
        Text("يلزم تحديد المدينة وطريقة حساب مواقيت الصلاة لإظهار بيانات صحيحة.",
            color = Color.White, fontSize = 13.sp)
    }
}

@Composable
private fun AdhkarScreen() {
    val adhkar = listOf(
        "سبحان الله وبحمده" to "100 مرة",
        "أستغفر الله" to "100 مرة",
        "لا إله إلا الله وحده لا شريك له" to "يُحدد العدد من مصدر الذكر"
    )
    ScreenColumn {
        Text("الأذكار", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("نماذج أولية للواجهة وليست مجموعة الأذكار الكاملة.", color = Color.White, fontSize = 12.sp)
        adhkar.forEach { (text, count) ->
            SectionCard(text, count, Icons.Filled.DarkMode, tint = Gold)
        }
        SectionCard("أذكار الصباح", "ستُضاف المجموعة الكاملة بعد مراجعة النصوص والمصادر.")
        SectionCard("أذكار المساء", "ستُضاف المجموعة الكاملة بعد مراجعة النصوص والمصادر.")
    }
}

@Composable
private fun TasbeehScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("noor_prefs", Context.MODE_PRIVATE) }
    var count by remember { mutableIntStateOf(prefs.getInt("tasbeeh_count", 0)) }
    ScreenColumn {
        SectionCard("عداد التسبيح", "اضغط على الزر لإضافة تسبيحة.", Icons.Filled.RadioButtonChecked, tint = Gold)
        Text(
            count.toString(),
            color = Gold, fontSize = 54.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
        )
        Button(
            onClick = {
                count += 1
                prefs.edit().putInt("tasbeeh_count", count).apply()
            },
            modifier = Modifier.fillMaxWidth().height(58.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Sky),
            shape = RoundedCornerShape(16.dp)
        ) { Text("سبّح", fontSize = 20.sp) }
        OutlinedButton(
            onClick = {
                count = 0
                prefs.edit().putInt("tasbeeh_count", 0).apply()
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("إعادة العداد", color = Color.White) }
    }
}

@Composable
private fun SimpleContentScreen(title: String, description: String) {
    ScreenColumn { SectionCard(title, description, Icons.Filled.AutoStories, tint = Gold) }
}

@Composable
private fun MoreScreen(onOpen: (Page) -> Unit) {
    ScreenColumn {
        listOf(Page.DUA, Page.TASBEEH, Page.HADITH, Page.CALENDAR, Page.ADHKAR, Page.PRAYER).forEach { p ->
            SectionCard(p.title, icon = p.icon(), onClick = { onOpen(p) })
        }
        SectionCard("عن التطبيق", "نور الإسلام — تطبيق إسلامي لخدمة المسلمين.")
    }
}
